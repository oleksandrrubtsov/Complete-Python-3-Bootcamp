# import zipfile
import shutil
import os
import re

dir_to_zip = "/Users/vrubtsov/Downloads/open_source_projects/Complete-Python-3-Bootcamp/12-Advanced Python Modules/08-Advanced-Python-Module-Exercise"

filename_output = 'example'

shutil.make_archive(filename_output,'zip', dir_to_zip)

shutil.unpack_archive('example.zip', 'final_unzip','zip')